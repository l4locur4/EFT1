/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eft_s9_eduardo_de_ferrari;

/**
 *EVALUACION FINAL TRANSVERSAL
 * @author Eduardo De Ferrari Dupuis
 * Semana 9
 * Fecha de entrega: 6 de Octubre
 */

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class EFT_S9_Eduardo_De_Ferrari {

    //Arreglos globales
    public static String[]menu={"Comprar entrada","Modificar entrada existente","Salir","Finalizar compra","Realizar otra compra"};//menu principal
    public static String[][] asientos = {
                { "PLA1", "PLB1", "|", "VA1", "VA2", "VA3", "VA4", "|", "PLC1", "PLD1", },
                { "PLA2", "PLB2", "|", "VB1", "VB2", "VB3", "VB4", "|", "PLC2", "PLD2", },
                { "PLA3", "PLB3", "|", "PA1", "PA2", "PA3", "PA4", "|", "PLC3", "PLD3", },
                { "PLA4", "PLB4", "|", "PB1", "PB2", "PB3", "PB4", "|", "PLC4", "PLD4", },
                { "PLA5", "PLB5", "|", "PC1", "PC2", "PC3", "PC4", "|", "PLC5", "PLD5", },
                { "PLA6", "PLB6", "|", "PD1", "PD2", "PD3", "PD4", "|", "PLC6", "PLD6", },
                { "PLA7", "PLB7", "|", "PE1", "PE2", "PE3", "PE4", "|", "PLC7", "PLD7", },
                { "PLA8", "PLB8", "|", "PF1", "PF2", "PF3", "PF4", "|", "PLC8", "PLD8", },
                { "PLA9", "PLB9", "|", "PG1", "PG2", "PG3", "PG4", "|", "PLC9", "PLD9", },
                { "PH1", "PH2", "PH3", "PH4", "PH5", "PH6", "PH7", "PH8", "PH9", "PH10", },
                { "PI1", "PI2", "PI3", "PI4", "PI5", "PI6", "PI7", "PI8", "PI9", "PI10", },
                { "PJ1", "PJ2", "PJ3", "PJ4", "PJ5", "PJ6", "PJ7", "PJ8", "PJ9", "PJ10", },
                { "PK1", "PK2", "PK3", "PK4", "PK5", "PK6", "PK7", "PK8", "PK9", "PK10", },
                { "GA1", "GA2", "GA3", "GA4", "GA5", "GA6", "GA7", "GA8", "GA9", "GA10", },
                { "GB1", "GB2", "GB3", "GB4", "GB5", "GB6", "GB7", "GB8", "GB9", "GB10", },
                { "GC1", "GC2", "GC3", "GC4", "GC5", "GC6", "GC7", "GC8", "GC9", "GC10", },
                { "GD1", "GD2", "GD3", "GD4", "GD5", "GD6", "GD7", "GD8", "GD9", "GD10", },
                { "GE1", "GE2", "GE3", "GE4", "GE5", "GE6", "GE7", "GE8", "GE9", "GE10", },
                { "GF1", "GF2", "GF3", "GF4", "GF5", "GF6", "GF7", "GF8", "GF9", "GF10", },
                { "GG1", "GG2", "GG3", "GG4", "GG5", "GG6", "GG7", "GG8", "GG9", "GG10", },
                { "GH1", "GH2", "GH3", "GH4", "GH5", "GH6", "GH7", "GH8", "GH9", "GH10", },
        };//asientos
    public static String[]cliente={"General","Estudiante","Menor","Mujeres","Tercera Edad"};//Tipo de cliente
    public static String[]tipoAsiento={"VIP","Platea Baja","Platea Alta","Palco derecha","Palco izquierda","Galeria"};
    public static Double[]precios={100000.0,70000.0,50000.0,40000.0,30000.0};
    
    public static List<String>Asiento=new ArrayList<>();
    public static List<String>TipoDeAsiento=new ArrayList<>();
    public static List<String>TipoDeCliente=new ArrayList<>();
    public static List<String>Nombre=new ArrayList<>();
    public static List<String>Reserva=new ArrayList<>();
    public static List<String>Venta=new ArrayList<>();
    public static List<String>IDCliente=new ArrayList<>();
    
    public static List<Double>Precios=new ArrayList<>();
    
    static int i=0; // contador de filas
    static int j=0; // contador de columnas
    static int fila=0;
    static int columna=0;
    static int edad=-1;
    static int genero=-1;
    static int estudiante=-1;
    static int modificar=0;

    static double precio=0;
    static double precioTotal=0;
    
    static boolean CONTINUAR=true;
    static boolean DISPONIBLE=true;
    
    static String asiento;


    public static void main(String[] args) {

        int opcion=0;
            Scanner scanner=new Scanner(System.in);
            System.out.println("===== BIENVENIDO AL TEATRO MORO =====");

            do{
                System.out.println("\n=== MENU ===");
                for(i=0;i<3;i++){ 
                    System.out.println((i+1)+". "+menu[i]); 
                }
                if(scanner.hasNextInt()){
                    opcion=scanner.nextInt();
                    switch(opcion){
                        case 1:
                            VentaDeEntradas(scanner);
                            break;
                        case 2:
                            ModificarVenta(scanner);
                            break;
                        case 3: 
                            CONTINUAR=false;
                            break;
                        default:
                            System.out.println("Opcion no valida.");
                    }
                }else{
                    System.out.println("Opcion no valida.");
                }
            }while(CONTINUAR);    
        }
    
    public static void seleccionarAsiento(Scanner scanner){
        int opcionasiento=0;
        
        do{
            //Asientos disponibles
            System.out.println("Asientos disponibles");
            System.out.println("\nPALCO IZD    ASIENTOS VIP     PALCO DCH");
            for(i=0;i<2;i++){
                for(j=0;j<asientos[i].length;j++){
                    System.out.print(asientos[i][j]+" ");
                }
                System.out.println();
            }
            System.out.println("\nPALCO IZD    PLATEA BAJA      PALCO DCH");
            for(i=2;i<9;i++){
                for(j=0;j<asientos[i].length;j++){
                    System.out.print(asientos[i][j]+" ");
                }
                System.out.println();
            }
            System.out.println("\n             PLATEA ALTA               ");
            for(i=9;i<13;i++){
                for(j=0;j<asientos[i].length;j++){
                    System.out.print(asientos[i][j]+" ");
                }
                System.out.println();
            }
            System.out.println("\n                GALERIA                ");
            for(i=13;i<21;i++){
                for(j=0;j<asientos[i].length;j++){
                    System.out.print(asientos[i][j]+" ");
                }
                System.out.println();
            }
            System.out.println("\nSeleccione el tipo de asiento:");
            for(i=0;i<tipoAsiento.length;i++){
                System.out.println((i+1)+". "+tipoAsiento[i]);
            }
            
            do{
                if(scanner.hasNextInt()){
                    opcionasiento=scanner.nextInt();
                    switch(opcionasiento){
                        case 1:
                            System.out.println("Seleccione la fila de su asiento:");
                            System.out.println("           1.VA  2.VB            ");
                            TipoDeAsiento.add(tipoAsiento[0]);
                            precio=precios[0];
                            break;
                        case 2:
                            System.out.println("Seleccione la fila de su asiento:");
                            System.out.println("      1.PA 2.PB 3.PC 4.PD        ");
                            System.out.println("        5.PE 6.PF 7.PG           ");
                            TipoDeAsiento.add(tipoAsiento[1]);
                            precio=precios[1];
                            break;
                        case 3:
                            System.out.println("Seleccione la fila de su asiento:");
                            System.out.println("      1.PH 2.PI 3.PJ 4.PK        ");
                            TipoDeAsiento.add(tipoAsiento[2]);
                            precio=precios[2];
                            break;
                        case 4:
                            System.out.println("Seleccione la columna 1 al 9.");
                            TipoDeAsiento.add(tipoAsiento[3]);
                            precio=precios[3];
                            break;
                        case 5:
                            System.out.println("Seleccione la columna 1 al 9.");
                            TipoDeAsiento.add(tipoAsiento[4]);
                            precio=precios[3];
                            break;
                        case 6:
                            System.out.println("Seleccione la fila de su asiento:");
                            System.out.println("      1.GA 2.GB 3.GC 4.GD        ");
                            System.out.println("      5.GE 6.GF 7.GG 8.GH        ");
                            TipoDeAsiento.add(tipoAsiento[5]);
                            precio=precios[4];
                            break;
                        default:
                            System.out.println("Opcion no valida. Ingrese el valor otra vez.");
                    }
                    
                }else{
                    System.out.println("Opcion no valida. Ingrese el valor otra vez.");
                }
            }while(opcionasiento<0||opcionasiento>6);
            
            do{
                if(scanner.hasNextInt()){
                    fila=scanner.nextInt();
                    if(fila<1||fila>21){
                        System.out.println("Opcion no valida. Vuelve a ingresar la fila.");
                    }else if (fila>2&&opcionasiento==1){
                        System.out.println("Solo puede ingresar el 1 y el 2.");
                    } else if (fila>7&&opcionasiento==2){
                        System.out.println("Solo puede ingresar del 1 al 7.");
                    }else if(fila>4&&opcionasiento==3){
                        System.out.println("Solo puede ingresar del 1 al 4.");
                    }else if((fila>9&&opcionasiento==4)||(fila>9&&opcionasiento==5)){
                        System.out.println("Solo puede ingresar del 1 al 9.");
                    }else if (fila>8&&opcionasiento==6){
                        System.out.println("Solo puede ingresar del 1 al 8.");
                    }
                }else{
                    System.out.println("Opcion no valida. Vuelve a ingresar la fila.");
                    scanner.next();
                }
            }while((fila<1||fila>21)||(fila>2&&opcionasiento==1)||(fila>7&&opcionasiento==2)||(fila>4&&opcionasiento==3)||(fila>9&&opcionasiento==4)||(fila>9&&opcionasiento==5)||(fila>8&&opcionasiento==6));
            
            switch (opcionasiento) {
                case 1:
                    System.out.println("Seleccione el numero de asiento del 1 al 4.");
                    break;
                case 2:
                    fila=fila+2;
                    System.out.println("Seleccione el numero de asiento del 1 al 4.");
                    break;
                case 3:
                    fila=fila+9;
                    System.out.println("Seleccione el número de asiento del 1 al 10:");
                    break;
                case 5:
                    System.out.println("Seleccione la fila de su asiento:");
                    System.out.println("1.PLA 2.PLB");
                    break;
                case 4:
                    System.out.println("Seleccione la fila de su asiento:");
                    System.out.println("1.PLC 2.PLD");
                    break;
                case 6:
                    fila=fila+13;
                    System.out.println("Seleccione el número de asiento del 1 al 10:");
                    break;
                default:
                    break;
            }
            
            do {
                if (scanner.hasNextInt()) {
                    columna = scanner.nextInt();
                    if (columna < 1 || columna > 10) {
                        System.out.println("Ingrese un número de asiento válido");
                    }else if((opcionasiento==1||opcionasiento==2)&&columna>4){
                        System.out.println("Solo puede ingresar un valor de 1 a 4.");
                    }else if((opcionasiento==4||opcionasiento==5)&&columna>2){
                        System.out.println("Solo puede ingresar los valores 1 y 2.");
                    }
                } else {
                    System.out.println("Opcion no valida. Ingrese el valor otra vez.");
                    scanner.next();
                }
            } while ((columna < 1 || columna > 10)||((opcionasiento==1||opcionasiento==2)&&columna>4)||((opcionasiento==4||opcionasiento==5)&&columna>2));
            
            if (opcionasiento==1||opcionasiento==2){
                columna=columna+3;
            }else if (opcionasiento==4){
                columna=columna+8;
            }
            
            asiento=asientos[fila-1][columna-1];
            Asiento.add(asiento);
           
            
            //System.out.println(Asiento);
           
             
            for(i=0;i<Asiento.size()-1;i++){
                if((Asiento.getLast()).equals(Asiento.get(i))){
                    System.out.println("Asiento NO disponible.");
                    Asiento.removeLast();
                    TipoDeAsiento.removeLast();

                    DISPONIBLE=false;
                }else{
                    DISPONIBLE=true;
                }
 
            }
            //System.out.println(Asiento);
            //System.out.println(TipoDeAsiento);
    
        }while (DISPONIBLE==false);
    }
    
    public static void Persona(Scanner scanner){
  
        String nombre;
        String apellido;
        
        
        Scanner nom=new Scanner(System.in);
        Scanner ape=new Scanner(System.in);
        
        System.out.println("Ingrese su nombre: ");
        nombre=nom.nextLine();

        System.out.println("Ingrese su apellido: ");
        apellido=ape.nextLine();
        Nombre.add(nombre+" "+apellido);
        
        System.out.println("Ingrese su edad.");
        do{
            if(scanner.hasNextInt()){
                edad=scanner.nextInt();
                if(edad<0||edad>120){
                    System.out.println("Ingrese una edad valida.");
                }  
            }else{
                System.out.println("Ingrese una edad valida.");
                scanner.next();
                
            }
        }while(edad<0||edad>120);
        
        if(edad<18){
            TipoDeCliente.add(cliente[2]);
            precio=precio*0.9;
            Precios.add(precio);
        }else if(edad>=18&&edad<60){
            System.out.println("Eres un(a) estudiante?");
            System.out.println("1.Si  2.No"); 
            do{
                if(scanner.hasNextInt()){
                    estudiante=scanner.nextInt();
                    if(estudiante<0||estudiante>2){
                        System.out.println("Opcion no valida. Vuelve a ingresar la opcion correctamente.");
                    }
                }else{
                    System.out.println("Opcion no valida. Vuelve a ingresar la opcion correctamente.");
                    scanner.next();
                }
            }while(estudiante<0||estudiante>2);
            if(estudiante==1){
                TipoDeCliente.add(cliente[1]);
                precio=precio*0.85;
                Precios.add(precio);
                //System.out.println(Precios);
                //System.out.println(precioTotal);
                
            }
                
            if(estudiante==2){
                System.out.println("Seleccione su genero:");
                System.out.println("1.Hombre  2.Mujer");
                do{
                    if(scanner.hasNextInt()){
                        genero=scanner.nextInt();
                        if (genero<0||genero>2){
                            System.out.println("Opcion no valida. Vuelve a ingresar la opcion correctamente.");

                        }
                    }else{
                        System.out.println("Opcion no valida. Vuelve a ingresar la opcion correctamente.");
                        scanner.next();

                    }
                }while(genero<0||genero>2);
            }

            if(genero==1){
                TipoDeCliente.add(cliente[0]);
                Precios.add(precio);

            }else if(genero==2){
                TipoDeCliente.add(cliente[3]);
                precio=precio*0.8;
                Precios.add(precio);

            }     
        }else if(edad>=60){
            TipoDeCliente.add(cliente[4]);
            precio=precio*0.75;
            Precios.add(precio);
        //System.out.println(TipoDeCliente);
        //System.out.println(Precios);
        }
        //System.out.println(Precios);
        //System.out.println(TipoDeCliente);
    }
    
    public static void VentaDeEntradas(Scanner scanner){
        
        int otraventa=0;
        
        seleccionarAsiento(scanner);
        Persona(scanner);
        
        if(modificar!=0){
            Reserva.set(modificar-1,(i+1)+". "+"IDCliente: "+Nombre.get(i)+" "+" Tarifa: "+TipoDeCliente.get(i)+" Asiento: "+Asiento.get(i)+" - "+TipoDeAsiento.get(i)+" Precio: $"+Precios.get(i));
            
            Nombre.remove(modificar-1);
            TipoDeCliente.remove(modificar-1);
            Asiento.remove(modificar-1);
            TipoDeAsiento.remove(modificar-1);
            Precios.remove(modificar-1);
            Precios.remove(i);
            precioTotal=0;
        }else{
            Reserva.add((i+1)+". "+"IDCliente: "+Nombre.get(i)+" "+" Tarifa: "+TipoDeCliente.get(i)+" Asiento: "+Asiento.get(i)+" - "+TipoDeAsiento.get(i)+" Precio: $"+Precios.get(i));
        }
            
        
        
        for(i=0;i<Precios.size();i++){
            precioTotal+=Precios.get(i);
            //System.out.println(Precios);
            //System.out.println(precioTotal);

        }
 
        System.out.println("========================== RESUMEN DE RESERVA ===========================");
        for(i=0;i<Reserva.size();i++){   
            System.out.println(Reserva.get(i));
        }
        System.out.println("_________________________________________________________________________");
        System.out.println("El precio total es: $"+precioTotal);   
        
        for(i=0;i<3;i++){ 
            System.out.println((i+1)+". "+menu[4-i]); 
        }
        
        do{
            if(scanner.hasNextInt()){
                otraventa=scanner.nextInt();
                switch(otraventa){
                    case 1:
                        precioTotal=0;
                        VentaDeEntradas(scanner); 
                        
                        break;
                    case 2:
                        imprimirBoleta(scanner);
                        CONTINUAR=false;
                        break;
                    case 3:
                        System.out.println("\nSu reserva quedo registrado en el sistema hasta que se concretre la compra. Puedes comprar mas entradas, modificar las ventas existentes o salir.");
                        System.out.println("En caso de salir, se perderan las reservas efectuadas anteriormente.");
                        break;
                    default:
                        System.out.println("Opcion no valida.");
                }
            }else{
                System.out.println("Opcion no valida.");
            }
        }while(otraventa<0||otraventa>3);
    }
    
    public static void ModificarVenta(Scanner scanner){
        int cambiar=0;
        int finalizarcompra=0;
        
        System.out.println("\nCual entrada desea modificar?");
        do{
            if(scanner.hasNextInt()){
                modificar=scanner.nextInt();
                if(modificar<0||modificar>Reserva.size()){
                    System.out.println("Entrada invalida o inexistente.");
                }
            }else{
                System.out.println("Entrada invalida o inexistente.");
            }
        }while(modificar<0||modificar>Reserva.size());
        
        System.out.println("Que modificacion desea realizar?");
        System.out.println("1.Remplazar 2.Eliminar");
        
        do{
            if(scanner.hasNextInt()){
                cambiar=scanner.nextInt();
                switch(cambiar){
                    case 1:
                        
                        VentaDeEntradas(scanner);
                        break;
                    case 2:
                        Reserva.remove(modificar-1);
                        Nombre.remove(modificar-1);
                        TipoDeCliente.remove(modificar-1);
                        Asiento.remove(modificar-1);
                        TipoDeAsiento.remove(modificar-1);
                        Precios.remove(modificar-1);
                        precioTotal=0;
                        break;
                    default:
                        System.out.println("Opcion invalida");
                        break;
                        
                }
            }else{
                System.out.println("Opcion invalida");
            }
        }while(cambiar<0||cambiar>2);
        
        if(precioTotal==0){
            for(i=0;i<Precios.size();i++){
            precioTotal+=Precios.get(i);

            }
        }
        
        System.out.println("========================== RESUMEN DE RESERVA ===========================");
        for(i=0;i<Reserva.size();i++){   
            System.out.println(Reserva.get(i));
        }
        System.out.println("_________________________________________________________________________");
        System.out.println("El precio total es: $"+precioTotal);   
        
        System.out.println("\nDeseas concretar la compra?");
        System.out.println("1.Si  2.No");

         do{
                if(scanner.hasNextInt()){
                    finalizarcompra=scanner.nextInt();
                    if(finalizarcompra<0||finalizarcompra>2){
                        System.out.println("Opcion no valida");
                    }else if(finalizarcompra==1){
                        imprimirBoleta(scanner);
                        CONTINUAR=false;
                        System.exit(0);
                    }

                }else{
                    System.out.println("Opcion no valida");
                }
            }while(finalizarcompra<0||finalizarcompra>2); 
        
    }
    
    public static void imprimirBoleta(Scanner scanner) {
        // Implementar funcionalidad de impresión de boleta si es necesario
        System.out.println("===========================================================================");
        System.out.println("                                 TEATRO MORO                               ");
        System.out.println("===========================================================================");
        for (i=0;i<Reserva.size();i++){
            IDCliente.add((i+1)+". "+"IDCliente: "+Nombre.get(i)+" Asiento: "+Asiento.get(i));
            System.out.println(IDCliente.get(i));
        }
        System.out.println("\n---------------------------------------------------------------------------");
        
        for (i = 0; i < Reserva.size(); i++) {
            Venta.add("ID Venta: "+(i+1)+ " Asiento: "+Asiento.get(i)+" - "+TipoDeAsiento.get(i)+" Tarifa: "+TipoDeCliente.get(i) +" Precio: $"+Precios.get(i));
            System.out.println(Venta.get(i));
        }
        System.out.println("___________________________________________________________________________");
      
        System.out.println("El precio total es: $"+precioTotal);
        
        System.out.println("===========================================================================");
        System.out.println("       MUCHAS GRACIAS POR SU COMPRA Y QUE DISFRUTE DE LA FUNCION           ");
        System.out.println("===========================================================================");
        CONTINUAR=false;
        System.exit(0);
    }    

}
